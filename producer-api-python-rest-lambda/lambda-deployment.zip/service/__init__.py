"""Event processing service."""

from .event_processing import EventProcessingService

__all__ = ["EventProcessingService"]
