"""Flask application wrapper for the Lambda handler."""

import asyncio
import json
import logging
from flask import Flask, request, jsonify
from flask_cors import CORS

from config import load_lambda_config
from constants import API_NAME
from models.event import Event
from repository import BusinessEventRepository, get_connection_pool, DuplicateEventError
from service import EventProcessingService

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger(__name__)

app = Flask(__name__)
CORS(app)

# Global service instance
_service: EventProcessingService | None = None


async def _initialize_service():
    """Initialize service with connection pool (singleton pattern)."""
    global _service
    
    if _service is None:
        _config = load_lambda_config()
        
        # Set log level from config
        if _config.log_level == "debug":
            logging.getLogger().setLevel(logging.DEBUG)
        elif _config.log_level == "warn":
            logging.getLogger().setLevel(logging.WARNING)
        elif _config.log_level == "error":
            logging.getLogger().setLevel(logging.ERROR)
        
        # Get connection pool
        pool = await get_connection_pool(_config.database_url)
        
        # Initialize repositories and service
        business_event_repo = BusinessEventRepository(pool)
        _service = EventProcessingService(business_event_repo, pool)
        
        logger.info(f"{API_NAME} Flask app initialized")
    
    return _service


def run_async(coro):
    """Run async function in sync context."""
    try:
        loop = asyncio.get_event_loop()
    except RuntimeError:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
    
    if loop.is_closed():
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
    
    return loop.run_until_complete(coro)


@app.route('/api/v1/events/health', methods=['GET'])
def health_check():
    """Health check endpoint."""
    return jsonify({
        "status": "healthy",
        "message": "Producer API is healthy",
    }), 200


@app.route('/api/v1/events', methods=['POST'])
def process_event():
    """Handle single event processing."""
    try:
        event_data = request.get_json()
        if not event_data:
            return jsonify({
                "error": "Invalid JSON",
                "status": 400,
            }), 400
        
        event = Event(**event_data)
    except json.JSONDecodeError as e:
        logger.warning(f"{API_NAME} Invalid JSON: {e}")
        return jsonify({
            "error": "Invalid JSON",
            "status": 400,
        }), 400
    except Exception as e:
        logger.warning(f"{API_NAME} Invalid event structure: {e}")
        return jsonify({
            "error": f"Invalid event structure: {str(e)}",
            "status": 422,
        }), 422
    
    # Validate event
    if not event.event_header.event_name:
        return jsonify({
            "error": "Event header event_name is required",
            "status": 422,
        }), 422
    
    if not event.event_body.entities:
        return jsonify({
            "error": "Event body must contain at least one entity",
            "status": 422,
        }), 422
    
    # Validate each entity
    for entity in event.event_body.entities:
        if not entity.entity_type:
            return jsonify({
                "error": "Entity type cannot be empty",
                "status": 422,
            }), 422
        if not entity.entity_id:
            return jsonify({
                "error": "Entity ID cannot be empty",
                "status": 422,
            }), 422
    
    logger.info(f"{API_NAME} Received event: {event.event_header.event_name}")
    
    # Process event
    try:
        service = run_async(_initialize_service())
        run_async(service.process_event(event))
        
        return jsonify({
            "success": True,
            "message": "Event processed successfully",
        }), 200
    except DuplicateEventError as e:
        logger.warning(f"{API_NAME} Duplicate event ID: {e.event_id}")
        return jsonify({
            "error": "Conflict",
            "message": e.message,
            "eventId": e.event_id,
            "status": 409,
        }), 409
    except Exception as e:
        logger.error(f"{API_NAME} Error processing event: {e}", exc_info=True)
        return jsonify({
            "error": f"Error processing event: {str(e)}",
            "status": 500,
        }), 500


@app.route('/api/v1/events/bulk', methods=['POST'])
def process_bulk_events():
    """Handle bulk event processing."""
    try:
        events_data = request.get_json()
        if not events_data:
            return jsonify({
                "error": "Invalid JSON",
                "status": 400,
            }), 400
        
        events = [Event(**event_data) for event_data in events_data]
    except json.JSONDecodeError as e:
        logger.warning(f"{API_NAME} Invalid JSON: {e}")
        return jsonify({
            "error": "Invalid JSON",
            "status": 400,
        }), 400
    except Exception as e:
        logger.warning(f"{API_NAME} Invalid event structure: {e}")
        return jsonify({
            "error": f"Invalid event structure: {str(e)}",
            "status": 422,
        }), 422
    
    if not events:
        return jsonify({
            "error": "Invalid request: events list is null or empty",
            "status": 422,
        }), 422
    
    logger.info(f"{API_NAME} Received bulk request with {len(events)} events")
    
    processed_count = 0
    failed_count = 0
    
    try:
        service = run_async(_initialize_service())
    except Exception as e:
        logger.error(f"{API_NAME} Error initializing service: {e}", exc_info=True)
        return jsonify({
            "error": f"Error initializing service: {str(e)}",
            "status": 500,
        }), 500
    
    for event in events:
        try:
            # Validate event
            if not event.event_header.event_name:
                failed_count += 1
                continue
            
            if not event.event_body.entities:
                failed_count += 1
                continue
            
            # Validate entities
            valid = True
            for entity in event.event_body.entities:
                if not entity.entity_type or not entity.entity_id:
                    valid = False
                    break
            
            if not valid:
                failed_count += 1
                continue
            
            run_async(service.process_event(event))
            processed_count += 1
        except DuplicateEventError as e:
            logger.warning(f"{API_NAME} Duplicate event ID in bulk: {e.event_id}")
            failed_count += 1
        except Exception as e:
            logger.error(f"{API_NAME} Error processing event in bulk: {e}", exc_info=True)
            failed_count += 1
    
    success = failed_count == 0
    message = (
        "All events processed successfully"
        if success
        else f"Processed {processed_count} events, {failed_count} failed"
    )
    
    return jsonify({
        "success": success,
        "message": message,
        "processedCount": processed_count,
        "failedCount": failed_count,
        "batchId": f"batch-{int(__import__('time').time() * 1000)}",
        "processingTimeMs": 100,  # Placeholder
    }), 200


if __name__ == '__main__':
    # Initialize service on startup
    run_async(_initialize_service())
    
    app.run(host='0.0.0.0', port=5000, debug=False)

