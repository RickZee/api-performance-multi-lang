"""Event header repository for database operations."""

import asyncpg
import json
import logging
import asyncio
from typing import Optional
from datetime import datetime
from repository.business_event_repo import DuplicateEventError

logger = logging.getLogger(__name__)

# Retry configuration
MAX_RETRIES = 3
INITIAL_RETRY_DELAY = 0.1  # 100ms
MAX_RETRY_DELAY = 2.0  # 2 seconds


class EventHeaderRepository:
    """Repository for event header database operations."""
    
    def __init__(self, pool: Optional[asyncpg.Pool] = None):
        """Initialize repository (pool is optional, connections are passed directly)."""
        self.pool = pool  # Kept for backward compatibility, but not used
    
    def _is_retryable_error(self, error: Exception) -> bool:
        """Check if error is retryable (connection/timeout/transaction conflicts).
        
        Includes DSQL OC000 transaction conflict errors which require retry
        due to Optimistic Concurrency Control (OCC).
        """
        error_str = str(error).lower()
        retryable_errors = [
            'connection',
            'timeout',
            'network',
            'unable to connect',
            'connection refused',
            'connection reset',
            'connection timed out',
            'server closed the connection',
            'could not connect',
            'network is unreachable',
            'no route to host',
            # DSQL transaction conflicts (OC000) - Optimistic Concurrency Control
            'conflicts with another transaction',
            'oc000',
            'mutation conflicts',
            'transaction conflict',
            'change conflicts',
        ]
        return any(err in error_str for err in retryable_errors)
    
    async def _retry_with_backoff(self, func, *args, **kwargs):
        """Retry function with exponential backoff."""
        delay = INITIAL_RETRY_DELAY
        last_error = None
        
        for attempt in range(MAX_RETRIES):
            try:
                return await func(*args, **kwargs)
            except DuplicateEventError:
                # Don't retry duplicate key errors - raise immediately
                raise
            except Exception as e:
                last_error = e
                
                # Check if error is retryable
                if not self._is_retryable_error(e) or attempt == MAX_RETRIES - 1:
                    raise
                
                # Exponential backoff
                logger.warning(
                    f"Retryable error on attempt {attempt + 1}/{MAX_RETRIES}: {e}. "
                    f"Retrying in {delay:.2f}s..."
                )
                await asyncio.sleep(delay)
                delay = min(delay * 2, MAX_RETRY_DELAY)
        
        # If we exhausted retries, raise the last error
        raise last_error
    
    async def create(self, event_id: str, event_name: str, event_type: Optional[str],
                     created_date: Optional[datetime], saved_date: Optional[datetime],
                     header_data: dict, conn: Optional[asyncpg.Connection] = None) -> None:
        """Create a new event header with retry logic.
        
        Args:
            event_id: Event ID (same as business_events.id)
            event_name: Event name
            event_type: Event type
            created_date: Created date
            saved_date: Saved date
            header_data: Full eventHeader JSON as dict
            conn: Optional database connection (for transactions). If not provided, acquires from pool.
        
        Raises:
            DuplicateEventError: If an event header with the same ID already exists (409 Conflict)
        """
        async def _do_create():
            if conn:
                # Use provided connection directly (transaction managed externally)
                await self._insert_header(conn, event_id, event_name, event_type,
                                        created_date, saved_date, header_data)
            else:
                # Connection should always be provided by service layer
                # This fallback should not be reached in normal operation
                raise ValueError("Connection must be provided (no pool available)")
        
        await self._retry_with_backoff(_do_create)
    
    async def _insert_header(self, conn: asyncpg.Connection, event_id: str, event_name: str,
                            event_type: Optional[str], created_date: Optional[datetime],
                            saved_date: Optional[datetime], header_data: dict) -> None:
        """Insert event header into database."""
        try:
            await conn.execute(
                """
                INSERT INTO event_headers (id, event_name, event_type, created_date, saved_date, header_data)
                VALUES ($1, $2, $3, $4, $5, $6)
                """,
                event_id,
                event_name,
                event_type,
                created_date,
                saved_date,
                json.dumps(header_data),
            )
        except asyncpg.UniqueViolationError as e:
            # Raise custom exception for duplicate key violations
            logger.warning(f"Duplicate event header ID detected: {event_id}")
            raise DuplicateEventError(event_id, f"Event header with ID '{event_id}' already exists") from e

