"""API constants for Producer API Python REST Lambda."""

API_NAME = "[producer-api-python-rest-lambda-pg]"
