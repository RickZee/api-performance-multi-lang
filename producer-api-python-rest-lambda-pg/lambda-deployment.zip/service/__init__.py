"""Event processing service - re-export from shared library."""

from producer_api_shared.service import EventProcessingService

__all__ = ["EventProcessingService"]
